/** < Include B&R Automation libraries (declarations for B&R ANSI C extensions) */
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

/** < Include header file with specified structures / enums, etc. */
#include "ax_ctrl.h"

/// Function block for controlling all basic functions of a single axis
_LOCAL struct MpAxisBasic MpAxisBasic_0;
/// Standard parameters for controlling axes (position, velocity, etc.)
_LOCAL struct MpAxisBasicParType AxisParameters;

/// Custom structure for axis control and data collection (more in the header file -> axCtrl_T.h)
_LOCAL struct motion_ctrl_main ctrl_lin_ax_0;

void _INIT ProgramInit(void)
{
	/// Declaration of function block inputs
	MpAxisBasic_0.Enable     = 1;			    ///< Enables the function block
	MpAxisBasic_0.MpLink     = &gAxis_1;		///< Connection to mapp (MpLink of an MpAxisBasic configuration)
	MpAxisBasic_0.Parameters = &AxisParameters;	///< Function block parameters

}	

void _CYCLIC ProgramCyclic(void)
{
	
}
